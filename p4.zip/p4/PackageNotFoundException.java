
@SuppressWarnings("serial")
public class PackageNotFoundException extends Exception {
	
}